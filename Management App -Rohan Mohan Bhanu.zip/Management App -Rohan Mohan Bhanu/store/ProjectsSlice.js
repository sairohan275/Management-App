import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
const initialState = {
  projects: [],
  status: 'idle',
  error: null,
};

export const fetchProjects = createAsyncThunk('projects/fetchProjects', async (id) => {
  const response = await fetch(`https://66209b523bf790e070b019e4.mockapi.io/api/v1/user/${id}/project`);
  if (!response.ok) {
    throw new Error('Failed to fetch projects');
  }
  const data = await response.json();
  return data;
});

export const addProject = createAsyncThunk('projects/addProject', async ({ id, name, description }) => {
  const response = await fetch(`https://66209b523bf790e070b019e4.mockapi.io/api/v1/user/${id}/project`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ name, description }),
  });
  if (!response.ok) {
    throw new Error('Failed to add project');
  }
  const data = await response.json();
  return data;
});

export const editProject = createAsyncThunk('projects/editProject', async ({ id, projectId, name, description }) => {
  const response = await fetch(`https://66209b523bf790e070b019e4.mockapi.io/api/v1/user/${id}/project/${projectId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ name, description }),
  });
  if (!response.ok) {
    throw new Error('Failed to edit project');
  }
  const data = await response.json();
  return data;
});
export const updateProjectNameLocally = createAsyncThunk(
  'projects/updateProjectNameLocally',
  async ({ projectId, newName }, thunkAPI) => {
    try {
      const response = await fetch(`https://66209b523bf790e070b019e4.mockapi.io/api/v1/user/${projectId}/project/${projectId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: newName }),
      });

      if (!response.ok) {
        throw new Error('Failed to update project name');
      }

      const updatedProject = await response.json();
      return updatedProject;
    } catch (error) {
      console.error('Error updating project name:', error);
      throw error; 
    }
  }
);

export const deleteProject = createAsyncThunk('projects/deleteProject', async ({ id, projectId }) => {
  const response = await fetch(`https://66209b523bf790e070b019e4.mockapi.io/api/v1/user/${id}/project/${projectId}`, {
    method: 'DELETE',
  });
  if (!response.ok) {
    throw new Error('Failed to delete project');
  }
  return projectId;
});

const projectsSlice = createSlice({
  name: 'projects',
  initialState,
  reducers: {
    toggleEditState(state, action) {
      const { projectId, isEditing } = action.payload;
      const project = state.projects.find((p) => p.id === projectId);
      if (project) {
        project.isEditing = isEditing;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProjects.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchProjects.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.projects = action.payload;
      })
      .addCase(fetchProjects.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
      .addCase(addProject.fulfilled, (state, action) => {
        state.projects.push(action.payload);
      })
      .addCase(editProject.fulfilled, (state, action) => {
        const updatedProject = action.payload;
        const existingProject = state.projects.find((p) => p.id === updatedProject.id);
        if (existingProject) {
          existingProject.name = updatedProject.name;
          existingProject.isEditing = false; 
        }
      })
      .addCase(updateProjectNameLocally.fulfilled, (state, action) => {
        // Find the updated project in state and update its name
        const updatedProject = action.payload;
        const existingProject = state.projects.find((p) => p.id === updatedProject.id);
        if (existingProject) {
          existingProject.name = updatedProject.name;
          existingProject.isEditing = false; // Turn off editing mode
        }
      })
      .addCase(updateProjectNameLocally.rejected, (state, action) => {
        state.error = action.error.message; // Update state with error message
      })
      .addCase(deleteProject.fulfilled, (state, action) => {
        const projectId = action.payload;
        state.projects = state.projects.filter((p) => p.id !== projectId);
      });
  },
});

export const { toggleEditState } = projectsSlice.actions;
export default projectsSlice.reducer;
