import React, { useEffect, useState } from "react";
import UserContext from "./UserContext";

export default function UserStore({ children }) {
  const [user, setUser] = useState([]);
  const [userId, setUserId] = useState("")
  const apiUrl = "https://66209b523bf790e070b019e4.mockapi.io/api/v1/user"

  async function getAllUsers(){
    const res = await fetch(apiUrl)
    const data = await res.json()
    setUser(data)
  }

  useEffect(()=>{
    getAllUsers()
  },[])
  function loginUser(email, password) {
    for(let i=0 ; i<user.length;i++){       
        if ( user[i].email === email && user[i].password === password) {
              setUserId(user[i].id)
            return user[i].id
        } 
    }
  return false
}

  return (
    <UserContext.Provider value={{ user, setUser,loginUser,userId }}>
      {children}
    </UserContext.Provider>
  );
}