import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchProjects, addProject, updateProjectNameLocally, deleteProject,toggleEditState } from '../store/ProjectsSlice';
import { useParams,Link } from 'react-router-dom';

const DashboardPage = () => {
  const {id,projectId}= useParams()
  const dispatch = useDispatch();
  const projects = useSelector((state) => state.projects.projects);
  const [newProjectData, setNewProjectData] = useState({ name: '', description: '' });
  const [usersData,setUsersData] = useState([]);

  useEffect(() => {
    dispatch(fetchProjects(id));
  }, [dispatch, id]);


  const handleAddProject = () => {
    dispatch(addProject({ id, ...newProjectData }));
    setNewProjectData({ name: '', description: '' });
  };

  const handleEditProject = (projectId) => {
    dispatch(toggleEditState({ projectId, isEditing: true }));
  };

  const handleProjectNameChange = (projectId, newName) => {
    setNewProjectData({ ...newProjectData, name: newName });
  };
  
  const handleSaveProjectName = (projectId, newName) => {
    dispatch(updateProjectNameLocally({ projectId, newName }));
    dispatch(toggleEditState({ projectId, isEditing: false }));
  };
  

  const handleDeleteProject = (projectId) => {
    dispatch(deleteProject({ id, projectId }));
  };
  const getUserData= async()=>{
    try{
    const apiUrl =`https://66209b523bf790e070b019e4.mockapi.io/api/v1/user/${id}`
    const  rep =  await fetch(apiUrl);
    if(rep.ok){
      const value = await rep.json()
      setUsersData(value);
     
    }else {
      console.error('Error fetching projects:', rep.statusText);
    }
  } catch (error) {
    console.error('Error fetching projects:', error);
  }
  }
  console.log(usersData)
  useEffect(() => {
    getUserData();
  }, []);

  return (
    <section className="bg-gray-50 dark:bg-gray-900 h-screen text-white">
      <div className='flex flex-row '>
        <div className=' w-1/3 py-3 px-2 mt-2 mx-2 rounded-lg shadow gap-3'>
          <aside className='border-r-2 border-white h-screen'>
            <img className='w-24 h-24 rounded-full ml-40' src={usersData.avatar} alt="User Avatar" />
            <h2 className='text-2xl text-center font-semibold mt-3'>{usersData.name}</h2>
            <h3 className='text-xl text-center font-extralight mt-1'>{usersData.email}</h3>
            <h3 className='text-xl text-center font-extralight mt-1'>{usersData.company}</h3>
          </aside>
        </div>
        <div className='w-2/3 py-3 px-2 rounded-lg shadow ml-3 mt-2 '>
          <h2 className='text-2xl'>Projects</h2>
          <div>
            <h3 className='my-2'>Add New Project</h3>
            <input
              className='h-8 p-3 rounded-md mb-5 text-black'
              type="text"
              value={newProjectData.name}
              onChange={(e) => setNewProjectData({ ...newProjectData, name: e.target.value })}
              placeholder="Project Name"
            /><br />
            <textarea
              className='p-4 rounded-md mb-2 text-black w-[80%]'
              type="text"
              value={newProjectData.description}
              onChange={(e) => setNewProjectData({ ...newProjectData, description: e.target.value })}
              placeholder="Project Description"
            /><br />
            <button className='bg-gray-500 rounded-md mb-3 p-2' onClick={handleAddProject}>Add Project</button>
          </div>
          <div>
            <h3 className='bg-gray-800 w-full p-3 '>Existing Projects</h3>
            <div className='grid grid-cols-3 gap-4'>
              {projects.map((project) => (
                <div className='shadow-sm shadow-gray-50 bg-gray-700 text-white mt-4 p-3 h-32 rounded-md' key={project.id}>
                  {project.isEditing ? (
                    <div>
                      <input
                        className='text-black'
                        type='text'
                        value={newProjectData.name}
                        onChange={(e) => handleProjectNameChange(project.id, e.target.value)}
                      />
                    </div>
                  ) : (
                    <Link to={`/dashboard/${id}/project/${project.id}`} className='block'>
                      <h2 className='text-center font-semibold'>{project.name}</h2>
                    </Link>
                  )}
                  <div className='flex ml-8 mt-8 gap-6'>
                    <button
                      className='bg-gray-900 hover:bg-gray-800 rounded-md px-3'
                      onClick={(event) => {
                        event.stopPropagation();
                        project.isEditing ? handleSaveProjectName(project.id, newProjectData.name) : handleEditProject(project.id);
                      }}
                    >
                      {project.isEditing ? 'Save' : 'Edit'}
                    </button>
                    <button
                      className='bg-gray-900 hover:bg-gray-800 rounded-md px-3'
                      onClick={(event) => {
                        event.stopPropagation();
                        handleDeleteProject(project.id);
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DashboardPage;
