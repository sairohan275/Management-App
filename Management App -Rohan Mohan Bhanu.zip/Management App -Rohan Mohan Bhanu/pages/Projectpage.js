import React, { useEffect, useState } from 'react'
import {useParams } from 'react-router-dom'


export default function Projectpage() {
  const {id,projectId} = useParams()
  const apiUrl = `https://66209b523bf790e070b019e4.mockapi.io/api/v1/user/${id}/project/${projectId}`
  const [projectData, setProjectData] = useState([]);
  const [loading, setLoading] = useState(true);

  async function getProjectData() {
    const res = await fetch(apiUrl);
    const data = await res.json();
    setProjectData(data);
    setLoading(false);
    
  }
  console.log(projectData)
  useEffect(() => {
    getProjectData();
  }, [projectData]);

  if(loading) return "Fetching data...."


  return (
    <body className='bg-gray-950 text-white p-3 h-[600px] border-t-4'>
    <div className='flex mt-10  gap-20'>
      <h1 className='text-3xl py-10'>{projectData.name}</h1>
      <p>{projectData.details}</p>
    </div>
    </body>
  );
}