import React from 'react'

export default function Header() {
  return (
    <div>
      <nav className=" bg-gray-950 text-white text-3xl font-semibold text-center py-6">Management App</nav>
    </div>
  )
}
