import { Route, Routes } from "react-router-dom";
import LoginPage from "./pages/Loginpage";
import DashboardPage from "./pages/Dashboardpage";
import RegisterPage from "./pages/RegisterPage";
import Header from "./component/Header";
import Projectpage from "./pages/Projectpage";

function App() {
  return (
    <>
      <Header/>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route
          path="/dashboard/:id"
          element={
              <DashboardPage />
          }
        ></Route>
        <Route path="/dashboard/:id/project/:projectId" element={<Projectpage/>}/>
        <Route path ="/register" element={<RegisterPage/>}/>

      </Routes>
    </>
  );
}

export default App;